package com.org.dto;

import lombok.Data;

@Data

public class Main {
	public static void main(String[] args) {
		User u=new User();
		u.setId(10);
		System.out.println(u.getId());
	}

}
